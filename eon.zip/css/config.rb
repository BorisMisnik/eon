http_path = "/"
css_dir = "."
sass_dir = "."
images_dir = "img"
javascripts_dir = "js"
output_style = :compressed
relative_assets=true
line_comments = false